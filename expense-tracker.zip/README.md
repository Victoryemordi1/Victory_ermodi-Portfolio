# Personal Expense Tracker

A simple command-line expense tracking application built with Python.

## Features

- Add expenses
- Categorize expenses
- View recorded expenses
- Calculate total spending
- View spending by category
- Delete expenses
- Store data locally in JSON format

## Technologies

- Python 3
- JSON
- pathlib
- datetime

## How to Run

Make sure Python 3 is installed.

```bash
python expense_tracker.py
```

## Future Improvements

- Monthly spending reports
- CSV export
- Budget limits
- Graphs and charts
- Web-based interface
- Database support
